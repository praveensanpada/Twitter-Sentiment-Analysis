from gtts import gTTS
import os

def getAns(text):
	mytext = text
	language = 'en'
	myobj = gTTS(text=mytext, lang=language, slow=False)
	myobj.save("static/welcome.mp3")
	os.system("mpg123 welcome.mp3")

